clear all;
clc;
close all;

% Load
load('C:\Users\Daniel\Google Drive\Masterarbeit\Camera Measurements\CameraParameter\CamParas.mat');
load('C:\Users\Daniel\Google Drive\Masterarbeit\Camera Measurements\CameraParameter\EstimationErr.mat');
cam=gigecam;
%% image aquisition
close all;
img = snapshot(cam);
[J,newOrigin] = undistortImage(img,cameraParams);
Jr = imrotate(J,0);
%BW = imbinarize(Jr,0.25);
imshow(Jr);
imwrite(Jr,'rep202.png')

%% Distance Measurement in image

corners = detectFASTFeatures(BW);

imshow(BW); hold on;
plot(corners.selectStrongest(50));


%% Image and World Points of Image for Pose estimation
%images = imageDatastore(fullfile(toolboxdir('vision'),'visiondata','calibration','slr'));
%[imagePoints,boardSize] = detectCheckerboardPoints(images.Files);
[imagePoints,boardSize] = detectCheckerboardPoints(Jr);
squareSize = 23; % in millimeters
worldPoints = generateCheckerboardPoints(boardSize,squareSize);
%imOrig=imread('C:\Users\Daniel\Google Drive\Masterarbeit\Camera Measurements\Matlab\cam1.png');
imOrig=Jr;
imshow(imOrig,'InitialMagnification',30);
imUndistorted = undistortImage(imOrig,cameraParams);
[imagePoints1,boardSize] = detectCheckerboardPoints(imUndistorted);
[R,t] = extrinsics(imagePoints1,worldPoints,cameraParams);
zCoord = zeros(size(worldPoints,1),1);
worldPoints = [worldPoints zCoord];
projectedPoints = worldToImage(cameraParams,R,t,worldPoints);
hold on
plot(projectedPoints(:,1),projectedPoints(:,2),'g*-');
legend('Projected points');
hold off

%% Pos Estimation

[worldOrientation,worldLocation] = estimateWorldCameraPose(imagePoints1,worldPoints,cameraParams);

pcshow(worldPoints,'VerticalAxis','Y','VerticalAxisDir','down', ...
     'MarkerSize',30);
 hold on
 plotCamera('Size',10,'Orientation',worldOrientation,'Location',...
     worldLocation);
 hold off



